import pygame
import os
from pygame import mixer
#from pygame.locals import *
import random


pygame.mixer.pre_init(44100, -16, 2, 512)
mixer.init()
pygame.init()


#define fps
clock = pygame.time.Clock()
fps = 60


screen_width = 750
screen_height = 750

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Space Invanders')


#define fonts
font30 = pygame.font.SysFont('Constantia', 30)
font40 = pygame.font.SysFont('Constantia', 40)


#load sounds
explosion_fx = pygame.mixer.Sound("img/explosion.wav")
explosion_fx.set_volume(0.25)

explosion2_fx = pygame.mixer.Sound("img/explosion2.wav")
explosion2_fx.set_volume(0.25)

laser_fx = pygame.mixer.Sound("img/laser.wav")
laser_fx.set_volume(0.25)


#define game variables
rows = 5
cols = 5
alien_cooldown = 1000#bullet cooldown in milliseconds
last_alien_shot = pygame.time.get_ticks()
countdown = 3
last_count = pygame.time.get_ticks()
game_over = 0#0 is no game over, 1 means player has won, -1 means player has lost

#define colours
red = (255, 0, 0)
green = (0, 255, 0)
white = (255, 255, 255)



#load image
bg = pygame.image.load("img/bg.png")

def draw_bg():
    screen.blit(bg, (0, 0))


#define function for creating text
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))



#create spaceship class
class Spaceship(pygame.sprite.Sprite):
    def __init__(self, x, y, health,c_no):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("img/spaceship.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.health_start = health
        self.health_remaining = health
        self.last_shot = pygame.time.get_ticks()
        self.c_no=c_no


    def update(self):
        #set movement speed
        speed = 8
        #set a cooldown variable
        cooldown = 500 #milliseconds
        game_over = 0


        #get key press
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= speed
        if key[pygame.K_RIGHT] and self.rect.right < screen_width:
            self.rect.x += speed

        #record current time
        time_now = pygame.time.get_ticks()
        #shoot
        if key[pygame.K_SPACE] and time_now - self.last_shot > cooldown:
            laser_fx.play()
            bullet = Bullets(self.rect.centerx, self.rect.top,self.c_no)
            self.c_no=bullet.c_no
            print(self.c_no)
            bullet_group.add(bullet)
            self.last_shot = time_now


        #update mask
        self.mask = pygame.mask.from_surface(self.image)


        #draw health bar
        pygame.draw.rect(screen, red, (self.rect.x, (self.rect.bottom + 10), self.rect.width, 15))
        if self.health_remaining > 0:
            pygame.draw.rect(screen, green, (self.rect.x, (self.rect.bottom + 10), int(self.rect.width * (self.health_remaining / self.health_start)), 15))
        elif self.health_remaining <= 0:
            explosion = Explosion(self.rect.centerx, self.rect.centery, 3)
            explosion_group.add(explosion)

            self.kill()
            game_over = -1
        return game_over



#create Bullets class
class Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y,c_no):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("img/bullet.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.c_no=c_no

    def update(self):
        self.rect.y -= 5
        if self.rect.bottom < 0:
            self.kill()
        if pygame.sprite.spritecollide(self, alien_group, True):
            self.kill()
            explosion_fx.play()
            explosion = Explosion(self.rect.centerx, self.rect.centery, 2)
            explosion_group.add(explosion)
            self.c_no+=10
    def get_c_no(self):
        return Bullets.c_no



#create Aliens class
class Aliens(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("img/alien" + str(random.randint(1, 5)) + ".png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.move_counter = 0
        self.move_direction = 1

    def update(self):
        self.rect.y += self.move_direction
        self.move_counter += 5


#create Alien Bullets class
class Alien_Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("img/alien_bullet.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]

    def update(self):
        self.rect.y += 2
        if self.rect.top > screen_height:
            self.kill()
        if pygame.sprite.spritecollide(self, spaceship_group, False, pygame.sprite.collide_mask):
            self.kill()
            explosion2_fx.play()
            #reduce spaceship health
            spaceship.health_remaining -= 1
            explosion = Explosion(self.rect.centerx, self.rect.centery, 1)
            explosion_group.add(explosion)




#create Explosion class
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, size):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for num in range(1, 6):
            img = pygame.image.load(f"img/exp{num}.png")
            if size == 1:
                img = pygame.transform.scale(img, (20, 20))
            if size == 2:
                img = pygame.transform.scale(img, (40, 40))
            if size == 3:
                img = pygame.transform.scale(img, (160, 160))
            #add the image to the list
            self.images.append(img)
        self.index = 0
        self.image = self.images[self.index]
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.counter = 0


    def update(self):
        explosion_speed = 3
        #update explosion animation
        self.counter += 1

        if self.counter >= explosion_speed and self.index < len(self.images) - 1:
            self.counter = 0
            self.index += 1
            self.image = self.images[self.index]

        #if the animation is complete, delete explosion
        if self.index >= len(self.images) - 1 and self.counter >= explosion_speed:
            self.kill()




#create sprite groups
spaceship_group = pygame.sprite.Group()
bullet_group = pygame.sprite.Group()
alien_group = pygame.sprite.Group()
alien_bullet_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()


def create_aliens():
    enemies = []
    wave_length = 5
    level = 0
    if len(enemies) == 0:
        level += 1
        wave_length += 5
        for i in range(wave_length):
            enemy = Aliens(random.randrange(50, screen_width - 100), random.randrange(-1500, -100))
            enemies.append(enemy)
            alien_group.add(enemy)
            if enemy.rect.y > screen_height:
                enemies.remove(enemy)


create_aliens()


#create player
spaceship = Spaceship(int(screen_width / 2), screen_height - 100, 3,0)
spaceship_group.add(spaceship)


def game(n, s):
    run = True
    alien_cooldown = 1000  # bullet cooldown in milliseconds
    last_alien_shot = pygame.time.get_ticks()
    countdown = 3
    last_count = pygame.time.get_ticks()
    game_over = 0  # 0 is no game over, 1 means player has won, -1 means player has lost
    c_no = spaceship.c_no
    print(c_no)
    game_font = pygame.font.SysFont("Corbel", 45)
    lost_font = pygame.font.SysFont("Corbel", 45)
    level = 0
    lives = 5
    while run:
        draw_bg()
        clock.tick(fps)
        lost_count = 0
        lives_icon = pygame.image.load(os.path.join("img", "live.png"))
        level_icon = pygame.image.load(os.path.join("img", "level.png"))
        lives_label = game_font.render(f"{lives}", 1, (255, 255, 255))
        level_label = game_font.render(f"{level}", 1, (0, 0, 0))
        settings = pygame.image.load(os.path.join("img", "settings.png"))
        coin = pygame.image.load(os.path.join("img", "coins.png"))
        screen.blit(lives_icon, (screen_width - level_label.get_width() - 200, 18))
        screen.blit(lives_label, (screen_width - level_label.get_width() - 230, 5))
        screen.blit(level_icon, (0, 6))
        screen.blit(settings, (screen_width - level_label.get_width() - 20, 15))
        screen.blit(level_label, (22, 12))
        coin_number = game_font.render(f"{c_no}", 1, (255, 255, 255))
        screen.blit(coin_number, (screen_width - level_label.get_width() - 133, 10))
        screen.blit(coin, (screen_width - level_label.get_width() - 90, 0))
    #draw background

        color = (255, 255, 255)

        if countdown == 0:
        #create random alien bullets
        #record current time
            time_now = pygame.time.get_ticks()
        #shoot
            if time_now - last_alien_shot > alien_cooldown and len(alien_bullet_group) < 5 and len(alien_group) > 0:
                attacking_alien = random.choice(alien_group.sprites())
                alien_bullet = Alien_Bullets(attacking_alien.rect.centerx, attacking_alien.rect.bottom)
                alien_bullet_group.add(alien_bullet)
                last_alien_shot = time_now

        #check if all the aliens have been killed
            if len(alien_group) == 0:
                game_over = 1

            if game_over == 0:
            #update spaceship
                game_over = spaceship.update()

            #update sprite groups
                bullet_group.update()
                alien_group.update()
                alien_bullet_group.update()
            else:
                if game_over == -1:
                    draw_text('GAME OVER!', font40, white, int(screen_width / 2 - 100), int(screen_height / 2 + 50))
                if game_over == 1:
                    draw_text('YOU WIN!', font40, white, int(screen_width / 2 - 100), int(screen_height / 2 + 50))
        if countdown > 0:
            draw_text('GET READY!', font40, white, int(screen_width / 2 - 110), int(screen_height / 2 + 50))
            draw_text(str(countdown), font40, white, int(screen_width / 2 - 10), int(screen_height / 2 + 100))
            count_timer = pygame.time.get_ticks()
            if count_timer - last_count > 1000:
                countdown -= 1
                last_count = count_timer



    #update explosion group
        explosion_group.update()


    #draw sprite groups
        spaceship_group.draw(screen)
        bullet_group.draw(screen)
        alien_group.draw(screen)
        alien_bullet_group.draw(screen)
        explosion_group.draw(screen)


    #event handlers
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False


        pygame.display.update()

def main_menu(n, state, buyed, s):
    run = True

    # white color
    color = (255, 255, 255)

    # light shade of the button
    color_light = (170, 170, 170)

    # dark shade of the button
    color_dark = (100, 100, 100)

    # defining a font
    smallfont = pygame.font.SysFont('Corbel', 35)

    # rendering a text written in
    # this font
    start = smallfont.render('START', True, color)
    title = smallfont.render('Space Invaders', True, color)
    store = smallfont.render('STORE', True, color)
    quit = smallfont.render('QUIT', True, color)

    while run:
        screen.blit(bg, (0, 0))
        mouse = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if screen_width / 2 - start.get_width() / 2 - 33 <= mouse[0] <= screen_width / 2 - start.get_width() / 2 + 107 and 245 <= mouse[1] <= 285:
                    game(n,s)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if screen_width / 2 - store.get_width() / 2 - 21 <= mouse[0] <= screen_width / 2 - store.get_width() / 2 + 107 and 300 <= mouse[1] <= 340:
                   store_game(n, state, buyed, s)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if screen_width / 2 - quit.get_width() / 2 <= mouse[0] <= screen_width / 2 - quit.get_width() / 2 + 107 and 355 <= \
                        mouse[1] <= 395:
                    pygame.quit()

                # fills the screen with a color

                # stores the (x,y) coordinates into
                # the variable as a tuple

                # if mouse is hovered on a button it
                # changes to lighter shade

        if screen_width / 2 - start.get_width() / 2 - 23 <= mouse[0] <= screen_width / 2 - start.get_width() / 2 + 117 and 245 <=mouse[1] <= 285:
            pygame.draw.rect(screen, color_light, [screen_width / 2 - start.get_width() / 2 - 23, 245, 140, 40])
        else:
            pygame.draw.rect(screen, color_dark, [screen_width / 2 - start.get_width() / 2 - 23, 245, 140, 40])

        if screen_width / 2 - store.get_width() / 2 - 21 <= mouse[0] <= screen_width / 2 - store.get_width() / 2 + 107 and 300 <=mouse[1] <= 340:
            pygame.draw.rect(screen, color_light, [screen_width / 2 - store.get_width() / 2 - 21, 300, 140, 40])
        else:
            pygame.draw.rect(screen, color_dark, [screen_width / 2 - store.get_width() / 2 - 21, 300, 140, 40])

        if screen_width / 2 - quit.get_width() / 2 - 33 <= mouse[0] <= screen_width / 2 - quit.get_width() / 2 + 107 and 355 <= mouse[1] <= 395:
            pygame.draw.rect(screen, color_light, [screen_width / 2 - quit.get_width() / 2 - 33, 355, 140, 40])
        else:
            pygame.draw.rect(screen, color_dark, [screen_width / 2 - quit.get_width() / 2 - 33, 355, 140, 40])

            # superimposing the text onto our button
        screen.blit(title, (screen_width / 2 - title.get_width() / 2, 100))
        screen.blit(start, (screen_width / 2 - start.get_width() / 2, 250))
        screen.blit(store, (screen_width / 2 - store.get_width() / 2, 305))
        screen.blit(quit, (screen_width / 2 - quit.get_width() / 2, 360))

        pygame.display.update()

def store_game(n, state, buyed, s):
    run = True
    FPS = 60
    game_font = pygame.font.SysFont("Corbel", 50)
    coin = pygame.image.load(os.path.join("img", "coins.png"))
    back = pygame.image.load(os.path.join("img", "back.png"))
    def_ship = pygame.image.load(os.path.join("img/store", "my_deffault_ship.png"))
    ship1 = pygame.image.load(os.path.join("img/store", "ship1.png"))
    ship2 = pygame.image.load(os.path.join("img/store", "ship2.png"))
    ship3 = pygame.image.load(os.path.join("img/store", "ship3.png"))
    ship4 = pygame.image.load(os.path.join("img/store", "ship4.png"))
    ship5 = pygame.image.load(os.path.join("img/store", "ship5.png"))
    ship6 = pygame.image.load(os.path.join("img/store", "ship6.png"))
    ship7 = pygame.image.load(os.path.join("img/store", "ship7.png"))
    arrow_left = pygame.image.load(os.path.join("img/store", "arl.png"))
    arrow_right = pygame.image.load(os.path.join("img/store", "arr.png"))
    uncheck = pygame.image.load(os.path.join("img/store", "uncheck.png"))
    check = pygame.image.load(os.path.join("img/store", "check.png"))
    buy = pygame.image.load(os.path.join("img/store", "buy.png"))
    gray_buy = pygame.image.load(os.path.join("img/store", "gray_buy.png"))
    images = [def_ship, ship1, ship2, ship3, ship4, ship5, ship6, ship7]
    prices = [0, 5, 15, 20, 25, 30, 35, 40]
    clock = pygame.time.Clock()
    back_button = 0
    buy_button = 0
    select_button = 0

    i = 0
    c_no = n

    while run:
        clock.tick(FPS)
        if state[i] == 0:
            screen.blit(bg, (0, 0))
            lives_label = game_font.render("Store", 1, (255, 255, 255))
            coin_number = game_font.render(f"{c_no}", 1, (255, 255, 255))
            screen.blit(lives_label, (0, 0))
            screen.blit(coin, (600, -10))
            screen.blit(coin_number, (655, -3))
            screen.blit(back, (10, 675))
            screen.blit(arrow_left, (100, 350))
            screen.blit(arrow_right, (590, 350))
            screen.blit(images[i], (250, 250))
            screen.blit(check, (362, 550))
        elif state[i] == 1:
            screen.blit(bg, (0, 0))
            lives_label = game_font.render("Store", 1, (255, 255, 255))
            coin_number = game_font.render(f"{c_no}", 1, (255, 255, 255))
            price = game_font.render(f"{prices[i]}", 1, (255, 255, 255))
            screen.blit(lives_label, (0, 0))
            screen.blit(coin, (600, -10))
            screen.blit(coin_number, (655, -3))
            screen.blit(back, (10, 675))
            screen.blit(arrow_left, (100, 350))
            screen.blit(arrow_right, (590, 350))
            screen.blit(coin, (300, 164))
            screen.blit(images[i], (250, 250))
            screen.blit(price, (360, 170))
            screen.blit(uncheck, (362, 550))
            screen.blit(gray_buy, (348, 590))
        elif state[i] == 2:
            screen.blit(bg, (0, 0))
            lives_label = game_font.render("Store", 1, (255, 255, 255))
            coin_number = game_font.render(f"{c_no}", 1, (255, 255, 255))
            price = game_font.render(f"{prices[i]}", 1, (255, 255, 255))
            screen.blit(lives_label, (0, 0))
            screen.blit(coin, (600, -10))
            screen.blit(coin_number, (655, -3))
            screen.blit(back, (10, 675))
            screen.blit(arrow_left, (100, 350))
            screen.blit(arrow_right, (590, 350))
            screen.blit(coin, (300, 164))
            screen.blit(images[i], (250, 250))
            screen.blit(price, (360, 170))
            screen.blit(uncheck, (362, 550))
            screen.blit(buy, (348, 590))
        elif state[i] == 3:
            screen.blit(bg, (0, 0))
            lives_label = game_font.render("Store", 1, (255, 255, 255))
            coin_number = game_font.render(f"{c_no}", 1, (255, 255, 255))
            screen.blit(lives_label, (0, 0))
            screen.blit(coin, (600, -10))
            screen.blit(coin_number, (655, -3))
            screen.blit(back, (10, 675))
            screen.blit(arrow_left, (100, 350))
            screen.blit(arrow_right, (590, 350))
            screen.blit(images[i], (250, 250))
            screen.blit(uncheck, (362, 550))

        if buy_button == 1 and c_no >= prices[i]:
            c_no = c_no - prices[i]
            l = 0

            for p in prices:
                if c_no <= p and buyed[l] != 1:
                    state[l] = 1
                l = l + 1
            state[i] = 3
            buyed[i] = 1
            buy_button = 0

        if select_button == 1 and buyed[i] == 1:
            k = 0
            for j in state:
                if j == 0:
                    state[k] = 3
                k = k + 1

            state[i] = 0
            s = i
            select_button = 0

        if back_button == 1:
            main_menu(c_no, state, buyed, s)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if x >= 590 and x <= 650 and y >= 350 and y <= 412:
                    if i >= 0 and i <= 6:
                        i = i + 1
                    else:
                        i = 0
                elif x >= 100 and x <= 163 and y >= 350 and y <= 412:
                    if i >= 1 and i <= 7:
                        i = i - 1
                    else:
                        i = 7
                elif x >= 15 and x <= 70 and y >= 680 and y <= 730:
                    back_button = 1
                elif x >= 350 and x <= 411 and y >= 603 and y <= 640 and c_no >= prices[i]:
                    buy_button = 1
                elif x >= 362 and x <= 393 and y >= 550 and y <= 580:
                    select_button = 1
x = 0
buyed = [1, 0, 0, 0, 0, 0, 0, 0]
state = [0, 1, 1, 1, 1, 1, 1, 1]
s = 0
main_menu(x, state, buyed, s)
pygame.quit()